# load the necessary libraries
from scipy.io import netcdf
import numpy as np
import matplotlib.pyplot as plt

# load the file
# file name
fn = "./out/example_0001_00000009.nc"
# load file
f = netcdf.netcdf_file(fn, 'r')

# species and index
# show aero_species
aero_species = f.variables['aero_species']
aero_species_ls = aero_species.names.decode().split(",")
aero_species_idx = aero_species.data
print("aerosol species list:", aero_species_ls)
print("aerosol species index:", aero_species_idx)

# aerosol statistics
# number conc. of the population
num_conc_per_particle = f.variables["aero_num_conc"].data
num_conc = num_conc_per_particle.sum()
# print("number conc.:", num_conc)

# calculate the percentage of each species in each particle
aero_particle_mass = f.variables["aero_particle_mass"].data
p = aero_particle_mass / aero_particle_mass.sum(axis=0)

### number fraction of particles are purely soot ### 
# use index 18 or -2
print("\n")
print("number fraction of particles that are purely soot:")
print(num_conc_per_particle[p[-2] == 1].sum()/num_conc,"\n")

### number fraction of particles that contain ammonium sulfate and soot ###
# sulfate: 0, ammonium: 3, soot: 18
print("number fraction of particles that contain ammonium sulfate and soot:")
print(num_conc_per_particle[(p[0]!=0) & (p[3]!=0) & (p[18]!=0)].sum()/num_conc,"\n")

### number fraction of particles that are soot-free ###
# soot: 18 or -2
print("number fraction of particles that that are soot-free:")
print(num_conc_per_particle[p[18]==0].sum()/num_conc,"\n")

